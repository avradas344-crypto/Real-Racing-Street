using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public static class CreateRaceScene
{
    [MenuItem("Real Racing Street/Create Starter Race Scene")]
    public static void Create()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects,
            NewSceneMode.Single);

        // Road
        var road = GameObject.CreatePrimitive(PrimitiveType.Cube);
        road.name = "Road";
        road.transform.position = new Vector3(0f, -0.5f, 45f);
        road.transform.localScale = new Vector3(12f, 1f, 120f);
        road.GetComponent<Renderer>().sharedMaterial = MakeMaterial(
            new Color(0.16f, 0.17f, 0.19f));

        // Road center stripe
        var stripe = GameObject.CreatePrimitive(PrimitiveType.Cube);
        stripe.name = "CenterStripe";
        stripe.transform.position = new Vector3(0f, 0.02f, 45f);
        stripe.transform.localScale = new Vector3(0.12f, 0.03f, 120f);
        stripe.GetComponent<Renderer>().sharedMaterial = MakeMaterial(Color.yellow);

        // Car root and visual body
        var car = new GameObject("PlayerCar");
        car.transform.position = new Vector3(0f, 0.55f, 3f);
        var rb = car.AddComponent<Rigidbody>();
        rb.mass = 1200f;
        rb.constraints = RigidbodyConstraints.FreezeRotationX |
                         RigidbodyConstraints.FreezeRotationZ;
        car.AddComponent<ArcadeCarController>();

        var body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.name = "CarBody";
        body.transform.SetParent(car.transform, false);
        body.transform.localPosition = new Vector3(0f, 0.35f, 0f);
        body.transform.localScale = new Vector3(1.8f, 0.65f, 3.4f);
        Object.DestroyImmediate(body.GetComponent<Collider>());
        body.GetComponent<Renderer>().sharedMaterial = MakeMaterial(
            new Color(0.08f, 0.28f, 0.8f));

        // Camera
        var camera = Camera.main;
        if (camera != null)
        {
            camera.transform.position = new Vector3(0f, 4.5f, -5f);
            camera.transform.rotation = Quaternion.Euler(18f, 0f, 0f);
            var follow = camera.gameObject.AddComponent<RaceFollowCamera>();
            follow.target = car.transform;
        }

        // UI
        var canvasObject = new GameObject("RaceCanvas",
            typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        if (Object.FindObjectOfType<EventSystem>() == null)
            new GameObject("EventSystem", typeof(EventSystem),
                typeof(StandaloneInputModule));

        CreateButton(canvas.transform, "LEFT", new Vector2(150, 150),
            new Vector2(0, 0), RaceTouchButton.ButtonAction.SteerLeft);
        CreateButton(canvas.transform, "RIGHT", new Vector2(150, 150),
            new Vector2(0, 0), RaceTouchButton.ButtonAction.SteerRight);
        CreateButton(canvas.transform, "GAS", new Vector2(180, 180),
            new Vector2(1, 0), RaceTouchButton.ButtonAction.Gas);
        CreateButton(canvas.transform, "BRAKE", new Vector2(150, 150),
            new Vector2(1, 0), RaceTouchButton.ButtonAction.Brake);

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/RaceScene.unity");
        Debug.Log("Starter scene created at Assets/Scenes/RaceScene.unity");
    }

    static void CreateButton(Transform parent, string label, Vector2 size,
        Vector2 corner, RaceTouchButton.ButtonAction action)
    {
        var go = new GameObject(label, typeof(RectTransform), typeof(Image),
            typeof(Button), typeof(RaceTouchButton));
        go.transform.SetParent(parent, false);

        var rect = go.GetComponent<RectTransform>();
        rect.sizeDelta = size;
        rect.anchorMin = corner;
        rect.anchorMax = corner;
        rect.pivot = new Vector2(corner.x == 0 ? 0 : 1, 0);
        rect.anchoredPosition = new Vector2(
            corner.x == 0 ? 40 : -40,
            label == "LEFT" ? 40 :
            label == "RIGHT" ? 210 :
            label == "GAS" ? 40 : 240);

        var image = go.GetComponent<Image>();
        image.color = new Color(0.1f, 0.1f, 0.1f, 0.7f);

        var btn = go.GetComponent<Button>();
        btn.transition = Selectable.Transition.None;

        var input = go.GetComponent<RaceTouchButton>();
        input.action = action;

        var textGo = new GameObject("Label", typeof(RectTransform), typeof(Text));
        textGo.transform.SetParent(go.transform, false);
        var text = textGo.GetComponent<Text>();
        text.text = label;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = 28;
        var textRect = textGo.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = Vector2.zero;
        textRect.offsetMax = Vector2.zero;
    }

    static Material MakeMaterial(Color color)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = color;
        return mat;
    }
}
