using UnityEngine;
using UnityEngine.EventSystems;

public class RaceTouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ButtonAction { SteerLeft, SteerRight, Gas, Brake }
    public ButtonAction action;

    public void OnPointerDown(PointerEventData eventData)
    {
        switch (action)
        {
            case ButtonAction.SteerLeft: RaceMobileInput.SetSteering(-1f); break;
            case ButtonAction.SteerRight: RaceMobileInput.SetSteering(1f); break;
            case ButtonAction.Gas: RaceMobileInput.SetThrottle(1f); break;
            case ButtonAction.Brake: RaceMobileInput.SetBrake(true); break;
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        switch (action)
        {
            case ButtonAction.SteerLeft:
            case ButtonAction.SteerRight: RaceMobileInput.SetSteering(0f); break;
            case ButtonAction.Gas: RaceMobileInput.SetThrottle(0f); break;
            case ButtonAction.Brake: RaceMobileInput.SetBrake(false); break;
        }
    }

    void OnDisable() => RaceMobileInput.ResetInput();
}
