using UnityEngine;

public class RaceFollowCamera : MonoBehaviour
{
    public Transform target;
    public Vector3 offset = new Vector3(0f, 4.2f, -7f);
    public float smoothSpeed = 6f;
    public float lookHeight = 1.1f;

    void LateUpdate()
    {
        if (!target) return;

        Vector3 wanted = target.position + target.TransformDirection(offset);
        transform.position = Vector3.Lerp(transform.position, wanted,
            smoothSpeed * Time.deltaTime);

        Vector3 lookPoint = target.position + Vector3.up * lookHeight;
        Quaternion wantedRotation = Quaternion.LookRotation(lookPoint - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, wantedRotation,
            smoothSpeed * Time.deltaTime);
    }
}
