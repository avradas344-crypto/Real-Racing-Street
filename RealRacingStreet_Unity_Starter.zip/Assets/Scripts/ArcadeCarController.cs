using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class ArcadeCarController : MonoBehaviour
{
    [Header("Driving")]
    public float acceleration = 18f;
    public float reverseAcceleration = 9f;
    public float maxForwardSpeed = 25f;
    public float maxReverseSpeed = 8f;
    public float steeringDegreesPerSecond = 75f;
    public float brakeStrength = 16f;
    public float lateralGrip = 5f;

    Rigidbody body;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.mass = 1200f;
        body.drag = 0.08f;
        body.angularDrag = 2.2f;
        body.interpolation = RigidbodyInterpolation.Interpolate;
        body.constraints = RigidbodyConstraints.FreezeRotationX |
                           RigidbodyConstraints.FreezeRotationZ;
    }

    void FixedUpdate()
    {
        float throttle = RaceMobileInput.Throttle;
        float steer = RaceMobileInput.Steering;
        Vector3 localVelocity = transform.InverseTransformDirection(body.velocity);

        if (throttle > 0f && localVelocity.z < maxForwardSpeed)
            body.AddForce(transform.forward * throttle * acceleration, ForceMode.Acceleration);
        else if (throttle < 0f && localVelocity.z > -maxReverseSpeed)
            body.AddForce(transform.forward * throttle * reverseAcceleration, ForceMode.Acceleration);

        if (RaceMobileInput.Brake)
            body.velocity = Vector3.MoveTowards(body.velocity, Vector3.zero,
                brakeStrength * Time.fixedDeltaTime);

        float speedFactor = Mathf.Clamp01(Mathf.Abs(localVelocity.z) / 2.5f);
        if (speedFactor > 0.01f)
        {
            float direction = localVelocity.z >= 0f ? 1f : -1f;
            body.MoveRotation(body.rotation * Quaternion.Euler(
                0f, steer * steeringDegreesPerSecond * speedFactor *
                direction * Time.fixedDeltaTime, 0f));
        }

        localVelocity = transform.InverseTransformDirection(body.velocity);
        localVelocity.x = Mathf.Lerp(localVelocity.x, 0f,
            lateralGrip * Time.fixedDeltaTime);
        body.velocity = transform.TransformDirection(localVelocity);
    }

    void OnDisable() => RaceMobileInput.ResetInput();
}
