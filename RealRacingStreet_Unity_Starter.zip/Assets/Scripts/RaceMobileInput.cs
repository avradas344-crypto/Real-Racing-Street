using UnityEngine;

public static class RaceMobileInput
{
    public static float Steering { get; private set; }
    public static float Throttle { get; private set; }
    public static bool Brake { get; private set; }

    public static void SetSteering(float value) => Steering = Mathf.Clamp(value, -1f, 1f);
    public static void SetThrottle(float value) => Throttle = Mathf.Clamp(value, -1f, 1f);
    public static void SetBrake(bool value) => Brake = value;

    public static void ResetInput()
    {
        Steering = 0f;
        Throttle = 0f;
        Brake = false;
    }
}
