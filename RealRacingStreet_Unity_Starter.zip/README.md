# Real Racing Street — Unity Starter (Android)

This is a Unity **source starter**, not a signed APK/AAB and not yet Play Store ready.

## Included
- Primitive placeholder car and road
- Rigidbody arcade car controller
- Chase camera
- Touch-and-hold steering, gas and brake controls
- Unity Editor menu command that generates the initial scene

## Create the scene
1. Open this folder as a Unity project in Unity Editor (Unity 2022.3 LTS or later recommended).
2. Wait for scripts to compile.
3. Choose **Real Racing Street > Create Starter Race Scene**.
4. Open `Assets/Scenes/RaceScene.unity`.
5. Press Play and test. Add the scene to Build Settings.

## Android build
In Unity Editor:
1. Install Android Build Support, Android SDK & NDK Tools, and OpenJDK through Unity Hub.
2. Switch platform to Android.
3. Set a unique Package Name in Player Settings (example: `com.yourstudio.realracingstreet`).
4. Set version and Android target API per the current Play Console requirements.
5. For Play Store publishing, build an Android App Bundle (`.aab`) and configure app signing.
6. Test on a physical Android device before release.

## Important limitations
- Placeholder visuals only. Replace the cube car with a licensed/free 3D model.
- No audio, menus, level progression, saved progress, ads, or monetization included.
- A cloud build service compiles a Unity project; it does not provide a complete Unity Editor in a mobile browser. A Unity Editor or supported remote/cloud editor environment is still needed to generate and test the scene.
- Google Play requires current account, testing, listing, privacy, and app-content requirements to be completed separately.
